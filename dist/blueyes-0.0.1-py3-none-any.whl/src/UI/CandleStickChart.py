from tkinter import Canvas

import matplotlib.pyplot as plt
import pandas as pd
from numpy import double


def get_xscroll_command()->str:
    return 'xscroll'



def get_yscroll_command()->str:
    return 'yscroll'


class CandleStickChart(object):
    def __init__(self, root):
        self.root = root

        # create figure



        # define width of candlestick elements
        width = .4
        width2 = .05

        # define up and down prices
        # create DataFrame
        prices = pd.read_csv('src/btc-prices.csv')
        open_: double = prices['Open']
        open_list = [open_]
        high_: double= prices['High']
        high_list = [high_]
        low_: double = prices['Low']
        low_list= [low_]
        close_: double= prices['Close']
        close_list = [close_]




        openvar = open_list
        highvar = high_list
        lowvar = low_list
        closevar = close_list

        price =pd.DataFrame({'Open': openvar,
                               'Close': closevar,
                               'High': highvar,
                               'Low': lowvar},
                              index=pd.date_range("2015-01-01", periods=8, freq="d"))



        # define up and down prices
        up = prices[prices.Close >=prices.Open]
        down = prices[prices.Close < prices.Open]
        print(prices)
        # display DataFrame

        # define colors to use
        col1 = 'green'
        col2 = 'red'

        # plot up prices
        plt.bar(up.index, up.Close - up.Open, width, bottom=up.Open, color=col1)
        plt.bar(up.index, up.High - up.Close, width2, bottom=up.Close, color=col1)
        plt.bar(up.index, up.Low - up.Open, width2, bottom=up.Open, color=col1)

        # plot down prices
        plt.bar(down.index, down.Close - down.Open, width, bottom=down.Open, color=col2)
        plt.bar(down.index, down.High - down.Open, width2, bottom=down.Open, color=col2)
        plt.bar(down.index, down.Low - down.Close, width2, bottom=down.Close, color=col2)

        # rotate x-axis tick labels
        plt.xticks(rotation=35, ha='right')

        plt.hist(up.index, color='red',label='Histogram')
        plt.scatter(up.index, up.Close - up.Open)

        plt.title('Pairs of BTC-USD')
        plt.xlabel('Time')
        plt.ylabel('Price')



        canvas=Canvas(master=root,takefocus=3,bg='black',borderwidth=1000,border=12,width=1000,height=500,selectbackground='blue')


        canvas.pack()
        plt.figure(facecolor='black',edgecolor='blue')

        plt.show()





        # display candlestick chart
