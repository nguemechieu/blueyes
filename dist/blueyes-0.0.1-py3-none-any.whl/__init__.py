
import numpy as np
import pandas as pd

# Ignore stupid divide by 0 warnings
np.seterr(divide="ignore", invalid="ignore")

pd.plotting.register_matplotlib_converters()
