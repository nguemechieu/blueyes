#!/usr/bin/env bash
echo "welcome to Blueyes"
echo "--------------------------------"
echo "Installation procedure for Blueyes is starting"

exec ./usr/local/bin/install --  bash
