
class BinanceUs(object):

        def __init__(self,currency=None):
                self.currency =currency

        def __str__(self): return self.currency        