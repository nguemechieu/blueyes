class CoinbasePro:
    def __init__(self, api_key, username, password, api_secret, pass_phrase):
        self.user = username
        self.password = password
        self.api_key = api_key
        self.api_secret = api_secret
        self.pass_phrase = pass_phrase


def create(): return


def trade(): return


def order(): return


def run(): return


def update(): return
