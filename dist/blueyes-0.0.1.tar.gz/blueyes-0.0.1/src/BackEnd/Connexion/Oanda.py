

class Oanda:
    def __init__(self, api_key, username, password):
        self.user = username
        self.password = password
        self.api_key = api_key


def create(): return


def trade(): return


def order(): return


def run(): return


def update(): return

