



class Oanda :
    def __init__(self, *args, **kwargs):
         self.user = kwargs.pop('user', None)
         self.password = kwargs.pop('password', None)
         self.email = kwargs.pop('email', None)
         

def create(): return 
def trade(): return
def order(): return
def run(): return
def update(): return
