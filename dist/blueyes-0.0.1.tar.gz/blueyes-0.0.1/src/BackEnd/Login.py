class Login :
  

  def __init__(self,username=None,password=None):

      self.username : username
      self.password : password
    
def __str__(self): return self.username + ' ' + self.password