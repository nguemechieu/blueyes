import tkinter
import matplotlib.pyplot as plt
import pandas as pd

from tkinter import X

from pygments.lexers import go


class CandleStickChart(object):

    def __init__(self, root):
        self.root = root
        canvas = tkinter.Canvas(root, background='black', borderwidth=10, width=1100, height=300, border=12,
                                relief='raised')
        canvas.create_line(160, 200, 600, 700, fill='white')
        canvas.pack(fill=X, side='left')

        # create figure
        plt.figure()

        # define width of candlestick elements
        width = .4
        width2 = .05

        # define up and down prices

        prices = pd.read_csv("btc-prices.csv")
        date = prices['Date'],
        open_ = prices['AAPL.Open'],
        high = prices['AAPL.High'],
        low = prices['AAPL.Low'],
        close = prices['AAPL.Close']
        volume = prices['AAPL.Volume']
        pricesclose = close
        pricesopen = high

        print(prices)

        up = prices[pricesclose >= open_]
        down = prices[pricesopen < low]

        # define colors to use
        col1 = 'green'
        col2 = 'red'

        # plot up prices
        plt.bar(up.index, up.close - up.open, width, bottom=up.open, color=col1)
        plt.bar(up.index, up.high - up.close, width2, bottom=up.close, color=col1)
        plt.bar(up.index, up.low - up.open, width2, bottom=up.open, color=col1)

        # plot down prices
        plt.bar(down.index, down.close - down.open, width, bottom=down.open, color=col2)
        plt.bar(down.index, down.high - down.open, width2, bottom=down.open, color=col2)
        plt.bar(down.index, down.low - down.close, width2, bottom=down.close, color=col2)

        # rotate x-axis tick labels
        plt.xticks(rotation=45, ha='right')

        # display candlestick chart
        plt.show()
        root.appendChild(plt)
