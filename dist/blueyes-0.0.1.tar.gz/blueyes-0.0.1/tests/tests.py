class Test:

    def __init__(self):
        super(Test, self).__init__()
