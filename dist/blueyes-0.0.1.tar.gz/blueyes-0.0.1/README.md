
# Blueyes

# Welcome to Blueyes

## License Agreement MIT License

### Getting Started with Blueyes

* Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution. Neither  the name of the copyright holder nor the names of its contributors may be used  to endorse or promote products derived from this software without specific prior written permission. For more information

# Installation Instructions 

 ## Virtual Environment
   * Docker image   (if available Recommended)

 ## Operating System 
    * Mac OS 
    * Windows
    * Linux

# Errors Report

    * Links to the git repository
[Error report link ](https://github.com/nguemechieu/blueyes/blog/master/issues)